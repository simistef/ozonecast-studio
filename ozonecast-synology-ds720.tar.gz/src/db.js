const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { parseUserAgent } = require('./parser');

function openDatabaseWithFallback() {
  const primaryDir = path.join(__dirname, '..', 'data');
  const fallbackDir = '/tmp/ozonecast-data';

  for (const dir of [primaryDir, fallbackDir]) {
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      const dbPath = path.join(dir, 'ozonecast.sqlite');
      const instance = new DatabaseSync(dbPath);
      try {
        instance.exec('PRAGMA journal_mode = WAL;');
      } catch (_) {
        instance.exec('PRAGMA journal_mode = DELETE;');
      }
      instance.exec('PRAGMA synchronous = NORMAL;');
      console.log(`SQLite initialized at ${dbPath}`);
      return instance;
    } catch (err) {
      console.warn(`Could not open SQLite in ${dir}: ${err.message}`);
    }
  }
  return new DatabaseSync(':memory:');
}

const db = openDatabaseWithFallback();

db.exec(`
  CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    mount TEXT NOT NULL,
    listener_count INTEGER NOT NULL,
    unique_ips INTEGER NOT NULL,
    peak_reported INTEGER DEFAULT 0,
    current_track TEXT DEFAULT '',
    bitrate INTEGER DEFAULT 128,
    source_mode TEXT DEFAULT 'live',
    human_count INTEGER DEFAULT NULL,
    human_unique_ips INTEGER DEFAULT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_snapshots_ts ON snapshots(ts);

  CREATE TABLE IF NOT EXISTS listener_sessions (
    session_key TEXT PRIMARY KEY,
    client_id TEXT,
    ip TEXT NOT NULL,
    mount TEXT NOT NULL,
    user_agent TEXT NOT NULL,
    player TEXT NOT NULL,
    category TEXT NOT NULL,
    os TEXT NOT NULL,
    country_code TEXT NOT NULL,
    country_name TEXT NOT NULL,
    city TEXT NOT NULL,
    lat REAL DEFAULT 0,
    lon REAL DEFAULT 0,
    first_seen INTEGER NOT NULL,
    last_seen INTEGER NOT NULL,
    duration_seconds INTEGER NOT NULL,
    is_active INTEGER DEFAULT 1,
    source_mode TEXT DEFAULT 'live'
  );
  CREATE INDEX IF NOT EXISTS idx_sessions_ip ON listener_sessions(ip);
  CREATE INDEX IF NOT EXISTS idx_sessions_last_seen ON listener_sessions(last_seen);
  CREATE INDEX IF NOT EXISTS idx_sessions_active ON listener_sessions(is_active);

  CREATE TABLE IF NOT EXISTS events_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    ip TEXT DEFAULT '',
    country_code TEXT DEFAULT '',
    city TEXT DEFAULT '',
    player TEXT DEFAULT '',
    duration_seconds INTEGER DEFAULT 0,
    details TEXT DEFAULT '',
    mount TEXT DEFAULT '/listen'
  );
  CREATE INDEX IF NOT EXISTS idx_events_ts ON events_log(ts DESC);

  CREATE TABLE IF NOT EXISTS ip_aliases (
    ip TEXT PRIMARY KEY,
    friendly_name TEXT NOT NULL,
    notes TEXT DEFAULT '',
    updated_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS bot_ips (
    ip TEXT PRIMARY KEY,
    reason TEXT DEFAULT '',
    created_at INTEGER NOT NULL
  );
`);

const DEFAULT_CONFIG = {
  baseUrl: process.env.ICECAST_URL || 'https://live.ozone.fm:8443',
  mount: process.env.ICECAST_MOUNT || '/listen',
  username: process.env.ICECAST_USER || 'admin',
  password: process.env.ICECAST_PASS || 'Wo10vn57zomq?',
  pollIntervalSec: parseInt(process.env.POLL_INTERVAL_SEC || '10', 10) || 10,
  ignoreTlsErrors: process.env.IGNORE_TLS_ERRORS !== 'false',
  sourceMode: process.env.SOURCE_MODE || 'auto', // 'auto' | 'live' | 'simulation'
  stationName: process.env.STATION_NAME || 'OZONE.FM',
  maxListenersCapacity: parseInt(process.env.MAX_LISTENERS || '500', 10) || 500,
  returningMinAvgSec: parseInt(process.env.RETURNING_MIN_AVG_SEC || '60', 10) >= 0
    ? parseInt(process.env.RETURNING_MIN_AVG_SEC || '60', 10)
    : 60,
  returningExcludeBots: process.env.RETURNING_EXCLUDE_BOTS !== 'false',
  requireDashboardAuth: process.env.REQUIRE_DASHBOARD_AUTH !== 'false',
};

function getConfig() {
  const rows = db.prepare('SELECT key, value FROM config').all();
  const cfg = { ...DEFAULT_CONFIG };
  for (const r of rows) {
    try {
      cfg[r.key] = JSON.parse(r.value);
    } catch (_) {
      cfg[r.key] = r.value;
    }
  }
  return cfg;
}

function updateConfig(partial) {
  const upsert = db.prepare(`
    INSERT INTO config (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `);
  const current = getConfig();
  const next = { ...current, ...partial };
  for (const [k, v] of Object.entries(partial)) {
    if (k in DEFAULT_CONFIG) {
      upsert.run(k, JSON.stringify(v));
    }
  }
  return next;
}

// Ensure human_count and human_unique_ips columns exist on existing databases
try {
  db.exec('ALTER TABLE snapshots ADD COLUMN human_count INTEGER DEFAULT NULL;');
} catch (_) {}
try {
  db.exec('ALTER TABLE snapshots ADD COLUMN human_unique_ips INTEGER DEFAULT NULL;');
} catch (_) {}
try {
  db.exec('UPDATE snapshots SET human_count = listener_count, human_unique_ips = unique_ips WHERE human_count IS NULL;');
} catch (_) {}
try {
  db.exec("ALTER TABLE listener_sessions ADD COLUMN last_track TEXT DEFAULT '';");
} catch (_) {}
try {
  db.exec("ALTER TABLE listener_sessions ADD COLUMN last_track_progress_sec INTEGER DEFAULT 0;");
} catch (_) {}

const insertSnapshotStmt = db.prepare(`
  INSERT INTO snapshots (ts, mount, listener_count, unique_ips, peak_reported, current_track, bitrate, source_mode, human_count, human_unique_ips)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

const insertEventStmt = db.prepare(`
  INSERT INTO events_log (ts, event_type, ip, country_code, city, player, duration_seconds, details, mount)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

// Clean up any stale rows where Role ('anonymous') was previously stored as user_agent,
// and ensure any historical bot/crawler sessions are tagged as 'Bot / Ripper'.
try {
  db.exec(`DELETE FROM listener_sessions WHERE LOWER(user_agent) = 'anonymous' OR LOWER(player) = 'anonymous';`);
  db.exec(`DELETE FROM events_log WHERE LOWER(player) = 'anonymous';`);
  db.exec(`
    UPDATE listener_sessions
    SET category = 'Bot / Ripper'
    WHERE LOWER(user_agent) LIKE '%bot%'
       OR LOWER(user_agent) LIKE '%onlineradiobox%'
       OR LOWER(user_agent) LIKE '%crawler%'
       OR LOWER(user_agent) LIKE '%spider%'
       OR LOWER(user_agent) LIKE '%streamripper%';
  `);
} catch (_) {}

const upsertSessionStmt = db.prepare(`
  INSERT INTO listener_sessions (
    session_key, client_id, ip, mount, user_agent, player, category, os,
    country_code, country_name, city, lat, lon,
    first_seen, last_seen, duration_seconds, is_active, source_mode, last_track, last_track_progress_sec
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
  ON CONFLICT(session_key) DO UPDATE SET
    client_id = excluded.client_id,
    user_agent = excluded.user_agent,
    player = excluded.player,
    category = excluded.category,
    os = excluded.os,
    first_seen = MIN(listener_sessions.first_seen, excluded.first_seen),
    last_seen = excluded.last_seen,
    duration_seconds = MAX(listener_sessions.duration_seconds, excluded.duration_seconds),
    is_active = 1,
    last_track = CASE WHEN excluded.last_track != '' THEN excluded.last_track ELSE listener_sessions.last_track END,
    last_track_progress_sec = excluded.last_track_progress_sec
`);

function recordPollResult({
  mount,
  enrichedListeners,
  reportedPeak,
  currentTrack,
  trackProgressSec = 0,
  bitrate,
  sourceMode,
  lastTrack,
}) {
  const now = Date.now();
  const uniqueIps = new Set(enrichedListeners.map(l => l.ip)).size;
  const humanListeners = enrichedListeners.filter(l => !l.isBot);
  const humanCount = humanListeners.length;
  const humanUniqueIps = new Set(humanListeners.map(l => l.ip)).size;

  insertSnapshotStmt.run(
    now,
    mount,
    enrichedListeners.length,
    uniqueIps,
    reportedPeak || enrichedListeners.length,
    currentTrack || '',
    bitrate || 128,
    sourceMode,
    humanCount,
    humanUniqueIps
  );

  if (currentTrack && lastTrack && currentTrack !== lastTrack) {
    insertEventStmt.run(
      now,
      'track',
      '',
      '',
      '',
      '',
      0,
      `Now Playing: ${currentTrack}`,
      mount
    );
  }

  const prevActiveRows = db
    .prepare('SELECT session_key, ip, country_code, city, player, duration_seconds FROM listener_sessions WHERE is_active = 1 AND source_mode = ?')
    .all(sourceMode);
  const prevMap = new Map(prevActiveRows.map(r => [r.session_key, r]));
  const currentKeys = new Set();

  for (const client of enrichedListeners) {
    const approxStartSec = Math.floor((now / 1000 - client.connectedSeconds) / 60);
    const sessionKey = `${sourceMode}:${client.ip}:${client.clientId || approxStartSec}`;
    currentKeys.add(sessionKey);

    const firstSeen = now - client.connectedSeconds * 1000;
    upsertSessionStmt.run(
      sessionKey,
      String(client.clientId),
      client.ip,
      mount,
      client.userAgent,
      client.ua.player,
      client.ua.category,
      client.ua.os,
      client.geo.countryCode,
      client.geo.countryName,
      client.geo.city,
      client.geo.lat,
      client.geo.lon,
      firstSeen,
      now,
      client.connectedSeconds,
      sourceMode,
      currentTrack || '',
      trackProgressSec || 0
    );

    if (!prevMap.has(sessionKey) && prevActiveRows.length > 0) {
      insertEventStmt.run(
        now,
        'join',
        client.ip,
        client.geo.countryCode,
        client.geo.city,
        client.ua.player,
        client.connectedSeconds,
        `Connected on ${mount}`,
        mount
      );
    }
  }

  const markInactiveStmt = db.prepare(`
    UPDATE listener_sessions
    SET is_active = 0,
        last_seen = ?,
        last_track = CASE WHEN ? != '' THEN ? ELSE last_track END,
        last_track_progress_sec = ?
    WHERE session_key = ?
  `);
  for (const [key, prev] of prevMap.entries()) {
    if (!currentKeys.has(key)) {
      const exitTrack = currentTrack || lastTrack || '';
      markInactiveStmt.run(now, exitTrack, exitTrack, trackProgressSec || 0, key);
      const progressLabel = trackProgressSec > 0 ? ` at ${formatDurationClock(trackProgressSec)}` : '';
      insertEventStmt.run(
        now,
        'leave',
        prev.ip,
        prev.country_code,
        prev.city,
        prev.player,
        prev.duration_seconds,
        `Disconnected after ${formatDurationShort(prev.duration_seconds)}${exitTrack ? ` (Track: ${exitTrack}${progressLabel})` : ''}`,
        mount
      );
    }
  }

  if (Math.random() < 0.05) {
    const fourteenDaysAgo = now - 14 * 24 * 3600 * 1000;
    db.prepare('DELETE FROM snapshots WHERE ts < ?').run(fourteenDaysAgo);
    db.prepare('DELETE FROM events_log WHERE id NOT IN (SELECT id FROM events_log ORDER BY ts DESC LIMIT 500)').run();
  }
}

function formatDurationClock(sec) {
  const s = Math.max(0, Math.floor(sec || 0));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${String(m).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

function formatDurationShort(sec) {
  const s = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${rem}s`;
  return `${rem}s`;
}

function getHistoricalSeries(rangeMinutes = 60, sourceMode = null, excludeBots = false) {
  const since = Date.now() - rangeMinutes * 60 * 1000;
  const countCol = excludeBots ? 'COALESCE(human_count, listener_count)' : 'listener_count';
  const ipCol = excludeBots ? 'COALESCE(human_unique_ips, unique_ips)' : 'unique_ips';

  let rows;
  if (sourceMode) {
    rows = db
      .prepare(`SELECT ts, ${countCol} as listener_count, ${ipCol} as unique_ips, peak_reported, current_track FROM snapshots WHERE ts >= ? AND source_mode = ? ORDER BY ts ASC`)
      .all(since, sourceMode);
  } else {
    rows = db
      .prepare(`SELECT ts, ${countCol} as listener_count, ${ipCol} as unique_ips, peak_reported, current_track FROM snapshots WHERE ts >= ? ORDER BY ts ASC`)
      .all(since);
  }

  if (rows.length <= 180) return rows;
  const step = Math.ceil(rows.length / 180);
  const sampled = [];
  for (let i = 0; i < rows.length; i += step) {
    const slice = rows.slice(i, i + step);
    const maxListeners = Math.max(...slice.map(r => r.listener_count));
    const avgListeners = Math.round(slice.reduce((a, b) => a + b.listener_count, 0) / slice.length);
    const last = slice[slice.length - 1];
    sampled.push({
      ts: last.ts,
      listener_count: avgListeners,
      max_in_bucket: maxListeners,
      unique_ips: last.unique_ips,
      peak_reported: last.peak_reported,
      current_track: last.current_track,
    });
  }
  return sampled;
}

/**
 * Computes 24-Hour Time-of-Day Listener Profile (00:00 to 23:00)
 * so the station owner can see when listeners usually tune in across the day,
 * plus daypart averages (Morning Drive, Midday Work, Evening Prime, Late Night).
 */
function getTimeOfDayProfile(sourceMode = 'live', excludeBots = false) {
  const sevenDaysAgo = Date.now() - 7 * 24 * 3600 * 1000;
  const countCol = excludeBots ? 'COALESCE(human_count, listener_count)' : 'listener_count';
  const ipCol = excludeBots ? 'COALESCE(human_unique_ips, unique_ips)' : 'unique_ips';

  const rows = db
    .prepare(`SELECT ts, ${countCol} as listener_count, ${ipCol} as unique_ips FROM snapshots WHERE ts >= ? AND source_mode = ?`)
    .all(sevenDaysAgo, sourceMode);

  const buckets = Array.from({ length: 24 }, (_, hour) => {
    let daypart = 'Late Night';
    if (hour >= 6 && hour < 11) daypart = 'Morning Drive';
    else if (hour >= 11 && hour < 17) daypart = 'Midday / Work';
    else if (hour >= 17 && hour < 23) daypart = 'Evening Prime';

    return {
      hour,
      label: `${String(hour).padStart(2, '0')}:00`,
      daypart,
      sumListeners: 0,
      maxListeners: 0,
      samples: 0,
    };
  });

  for (const r of rows) {
    const d = new Date(r.ts);
    const h = d.getHours();
    const b = buckets[h];
    if (b) {
      b.sumListeners += r.listener_count || 0;
      if ((r.listener_count || 0) > b.maxListeners) {
        b.maxListeners = r.listener_count;
      }
      b.samples++;
    }
  }

  const hourly = buckets.map(b => ({
    hour: b.hour,
    label: b.label,
    daypart: b.daypart,
    avgListeners: b.samples > 0 ? Math.round(b.sumListeners / b.samples) : 0,
    peakListeners: b.maxListeners,
    samples: b.samples,
  }));

  // Compute daypart summaries
  const dayparts = [
    { id: 'morning', name: 'Morning Drive', hours: '06:00 – 11:00', filter: h => h >= 6 && h < 11 },
    { id: 'midday', name: 'Midday / Workday', hours: '11:00 – 17:00', filter: h => h >= 11 && h < 17 },
    { id: 'evening', name: 'Evening Prime Time', hours: '17:00 – 23:00', filter: h => h >= 17 && h < 23 },
    { id: 'night', name: 'Late Night / Overnight', hours: '23:00 – 06:00', filter: h => h >= 23 || h < 6 },
  ].map(dp => {
    const matching = hourly.filter(h => dp.filter(h.hour) && h.samples > 0);
    const avg = matching.length > 0
      ? Math.round(matching.reduce((s, x) => s + x.avgListeners, 0) / matching.length)
      : 0;
    const peak = matching.length > 0
      ? Math.max(...matching.map(x => x.peakListeners))
      : 0;
    return {
      id: dp.id,
      name: dp.name,
      hours: dp.hours,
      avgListeners: avg,
      peakListeners: peak,
    };
  });

  const bestHour = [...hourly].sort((a, b) => b.avgListeners - a.avgListeners || b.peakListeners - a.peakListeners)[0] || hourly[20];
  const bestDaypart = [...dayparts].sort((a, b) => b.avgListeners - a.avgListeners)[0] || dayparts[2];

  return {
    hourly,
    dayparts,
    bestHourLabel: bestHour ? `${bestHour.label} – ${String((bestHour.hour + 1) % 24).padStart(2, '0')}:00` : '20:00 – 21:00',
    bestHourAvg: bestHour?.avgListeners || 0,
    bestHourPeak: bestHour?.peakListeners || 0,
    bestDaypartName: bestDaypart?.name || 'Evening Prime Time',
  };
}

function getIpAliasesMap() {
  const rows = db.prepare('SELECT ip, friendly_name, notes, updated_at FROM ip_aliases').all();
  const map = {};
  for (const r of rows) {
    map[r.ip] = {
      ip: r.ip,
      friendlyName: r.friendly_name,
      notes: r.notes || '',
      updatedAt: r.updated_at,
    };
  }
  return map;
}

function getIpAlias(ip) {
  const clean = String(ip || '').trim();
  if (!clean) return null;
  const r = db.prepare('SELECT ip, friendly_name, notes, updated_at FROM ip_aliases WHERE ip = ?').get(clean);
  if (!r) return null;
  return {
    ip: r.ip,
    friendlyName: r.friendly_name,
    notes: r.notes || '',
    updatedAt: r.updated_at,
  };
}

function setIpAlias(ip, friendlyName, notes = '') {
  const cleanIp = String(ip || '').trim();
  if (!cleanIp) throw new Error('IP address is required');
  const cleanName = String(friendlyName || '').trim();
  const cleanNotes = String(notes || '').trim();
  const now = Date.now();

  if (!cleanName) {
    db.prepare('DELETE FROM ip_aliases WHERE ip = ?').run(cleanIp);
    return { ip: cleanIp, friendlyName: '', notes: '', updatedAt: now };
  }

  db.prepare(`
    INSERT INTO ip_aliases (ip, friendly_name, notes, updated_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(ip) DO UPDATE SET
      friendly_name = excluded.friendly_name,
      notes = excluded.notes,
      updated_at = excluded.updated_at
  `).run(cleanIp, cleanName, cleanNotes, now);

  return { ip: cleanIp, friendlyName: cleanName, notes: cleanNotes, updatedAt: now };
}

/**
 * Returns the Top N Returning Listeners ranked by distinct session visits & cumulative connected time.
 * Excludes bots/crawlers (when returningExcludeBots is true) and listeners with average connection
 * time below returningMinAvgSec (default 60s = 1 minute).
 */
function getTopReturningListeners(limit = 5, sourceMode = 'live') {
  const cfg = getConfig();
  const minAvgSec = Math.max(0, Number(cfg.returningMinAvgSec ?? 60));
  const excludeBots = cfg.returningExcludeBots !== false ? 1 : 0;
  const aliases = getIpAliasesMap();

  const rows = db
    .prepare(`
      SELECT
        ip,
        COUNT(*) as session_count,
        SUM(duration_seconds) as total_duration_seconds,
        ROUND(AVG(duration_seconds)) as avg_duration_seconds,
        MAX(duration_seconds) as longest_session_seconds,
        MIN(first_seen) as first_seen,
        MAX(last_seen) as last_seen,
        MAX(is_active) as is_active,
        MAX(player) as player,
        MAX(category) as category,
        MAX(os) as os,
        MAX(city) as city,
        MAX(country_code) as country_code,
        MAX(country_name) as country_name
      FROM listener_sessions
      WHERE source_mode = ?
        AND (? = 0 OR (
          category != 'Bot / Ripper'
          AND ip NOT IN (SELECT ip FROM bot_ips)
          AND LOWER(user_agent) NOT LIKE '%bot%'
          AND LOWER(user_agent) NOT LIKE '%onlineradiobox%'
          AND LOWER(user_agent) NOT LIKE '%crawler%'
          AND LOWER(user_agent) NOT LIKE '%spider%'
          AND LOWER(user_agent) NOT LIKE '%streamripper%'
        ))
      GROUP BY ip
      HAVING AVG(duration_seconds) >= ?
      ORDER BY session_count DESC, total_duration_seconds DESC
      LIMIT ?
    `)
    .all(sourceMode, excludeBots, minAvgSec, limit);

  return rows.map((r, idx) => ({
    rank: idx + 1,
    ip: r.ip,
    friendlyName: aliases[r.ip]?.friendlyName || '',
    notes: aliases[r.ip]?.notes || '',
    sessionCount: Number(r.session_count) || 1,
    totalDurationSeconds: Number(r.total_duration_seconds) || 0,
    avgDurationSeconds: Number(r.avg_duration_seconds) || 0,
    longestSessionSeconds: Number(r.longest_session_seconds) || 0,
    firstSeen: r.first_seen,
    lastSeen: r.last_seen,
    isActive: Number(r.is_active) === 1,
    player: r.player || 'Audio Client',
    category: r.category || 'Client',
    os: r.os || 'Unknown',
    city: r.city || 'Unknown',
    countryCode: r.country_code || 'RO',
    countryName: r.country_name || 'Romania',
  }));
}

function getAggregatedStats(sourceMode = 'live', excludeBots = false) {
  const now = Date.now();
  const dayAgo = now - 24 * 3600 * 1000;
  const cfg = getConfig();
  const minAvgSec = Math.max(0, Number(cfg.returningMinAvgSec ?? 60));
  const excludeFlag = excludeBots || cfg.returningExcludeBots !== false ? 1 : 0;
  const countCol = excludeBots ? 'COALESCE(human_count, listener_count)' : 'listener_count';

  const peak24hRow = db
    .prepare(`SELECT ${countCol} as listener_count, ts, peak_reported FROM snapshots WHERE ts >= ? AND source_mode = ? ORDER BY ${countCol} DESC LIMIT 1`)
    .get(dayAgo, sourceMode);

  const allTimePeakRow = db
    .prepare(`SELECT MAX( MAX(${countCol}), MAX(peak_reported) ) as peak, ts FROM snapshots WHERE source_mode = ?`)
    .get(sourceMode);

  const sessionStats24h = db
    .prepare(`
      SELECT
        COUNT(*) as total_sessions,
        COUNT(DISTINCT ip) as unique_ips_24h,
        COUNT(DISTINCT country_code) as unique_countries_24h,
        AVG(duration_seconds) as avg_duration_sec,
        SUM(duration_seconds) as total_listening_sec
      FROM listener_sessions
      WHERE last_seen >= ? AND source_mode = ?
        AND (? = 0 OR (
          category != 'Bot / Ripper'
          AND ip NOT IN (SELECT ip FROM bot_ips)
          AND LOWER(user_agent) NOT LIKE '%bot%'
          AND LOWER(user_agent) NOT LIKE '%onlineradiobox%'
          AND LOWER(user_agent) NOT LIKE '%crawler%'
          AND LOWER(user_agent) NOT LIKE '%spider%'
          AND LOWER(user_agent) NOT LIKE '%streamripper%'
        ))
    `)
    .get(dayAgo, sourceMode, excludeBots ? 1 : 0);

  const returningCountRow = db
    .prepare(`
      SELECT COUNT(*) as returning_ips
      FROM (
        SELECT ip
        FROM listener_sessions
        WHERE source_mode = ?
          AND (? = 0 OR (
            category != 'Bot / Ripper'
            AND ip NOT IN (SELECT ip FROM bot_ips)
            AND LOWER(user_agent) NOT LIKE '%bot%'
            AND LOWER(user_agent) NOT LIKE '%onlineradiobox%'
            AND LOWER(user_agent) NOT LIKE '%crawler%'
            AND LOWER(user_agent) NOT LIKE '%spider%'
            AND LOWER(user_agent) NOT LIKE '%streamripper%'
          ))
        GROUP BY ip
        HAVING COUNT(*) > 1 AND AVG(duration_seconds) >= ?
      )
    `)
    .get(sourceMode, excludeFlag, minAvgSec);

  const recentEvents = db
    .prepare('SELECT * FROM events_log ORDER BY ts DESC LIMIT 60')
    .all();

  return {
    peak24h: peak24hRow ? Math.max(peak24hRow.listener_count, peak24hRow.peak_reported || 0) : 0,
    peak24hTs: peak24hRow ? peak24hRow.ts : now,
    allTimePeak: allTimePeakRow?.peak || 0,
    totalSessions24h: sessionStats24h?.total_sessions || 0,
    uniqueIps24h: sessionStats24h?.unique_ips_24h || 0,
    uniqueCountries24h: sessionStats24h?.unique_countries_24h || 0,
    avgDuration24hSec: Math.round(sessionStats24h?.avg_duration_sec || 0),
    totalListeningHours24h: Number(((sessionStats24h?.total_listening_sec || 0) / 3600).toFixed(2)),
    returningListenerCount: returningCountRow?.returning_ips || 0,
    returningMinAvgSec: minAvgSec,
    returningExcludeBots: Boolean(excludeBots),
    recentEvents,
  };
}

function getBotIpsSet() {
  const rows = db.prepare('SELECT ip FROM bot_ips').all();
  return new Set(rows.map(r => r.ip));
}

function isBotIp(ip) {
  if (!ip) return false;
  return Boolean(db.prepare('SELECT 1 FROM bot_ips WHERE ip = ?').get(ip));
}

function setBotIp(ip, isBot, reason = '') {
  const cleanIp = String(ip || '').trim();
  if (!cleanIp) return false;
  const now = Date.now();

  if (isBot) {
    db.prepare(`
      INSERT INTO bot_ips (ip, reason, created_at)
      VALUES (?, ?, ?)
      ON CONFLICT(ip) DO UPDATE SET reason = excluded.reason, created_at = excluded.created_at
    `).run(cleanIp, String(reason || 'Manually marked as Bot / Ripper'), now);

    db.prepare(`
      UPDATE listener_sessions
      SET category = 'Bot / Ripper'
      WHERE ip = ?
    `).run(cleanIp);

    insertEventStmt.run(now, 'bot_flag', cleanIp, '', '', 'Bot / Ripper', 0, 'Flagged as Bot / Ripper', '/listen');
    return true;
  } else {
    db.prepare('DELETE FROM bot_ips WHERE ip = ?').run(cleanIp);

    const sessions = db.prepare('SELECT session_key, user_agent FROM listener_sessions WHERE ip = ?').all(cleanIp);
    const updateStmt = db.prepare('UPDATE listener_sessions SET category = ?, player = ?, os = ? WHERE session_key = ?');
    for (const s of sessions) {
      const parsed = parseUserAgent(s.user_agent);
      updateStmt.run(parsed.category, parsed.player, parsed.os, s.session_key);
    }

    insertEventStmt.run(now, 'bot_unflag', cleanIp, '', '', '', 0, 'Removed Bot / Ripper flag', '/listen');
    return false;
  }
}

function findTrackStartTs(trackName, exitTs) {
  if (!trackName || !exitTs) return null;
  const event = db.prepare(`
    SELECT ts FROM events_log
    WHERE event_type = 'track'
      AND details = ?
      AND ts <= ?
      AND ts >= ? - (30 * 60 * 1000)
    ORDER BY ts DESC
    LIMIT 1
  `).get(`Now Playing: ${trackName}`, exitTs, exitTs);

  if (event && event.ts) return event.ts;

  const snaps = db.prepare(`
    SELECT ts, current_track
    FROM snapshots
    WHERE ts <= ? AND ts >= ? - (30 * 60 * 1000)
    ORDER BY ts DESC
    LIMIT 60
  `).all(exitTs, exitTs);

  let earliest = null;
  for (const snap of snaps) {
    if (snap.current_track === trackName) {
      earliest = snap.ts;
    } else {
      break;
    }
  }
  return earliest;
}

function getIpHistory(ip) {
  const sessions = db
    .prepare('SELECT * FROM listener_sessions WHERE ip = ? ORDER BY last_seen DESC LIMIT 50')
    .all(ip);

  const findTrackStmt = db.prepare(`
    SELECT current_track
    FROM snapshots
    WHERE ts <= ? AND LENGTH(current_track) > 0
    ORDER BY ts DESC
    LIMIT 1
  `);

  for (const s of sessions) {
    if (!s.last_track) {
      const snap = findTrackStmt.get(s.last_seen);
      if (snap && snap.current_track) {
        s.last_track = snap.current_track;
      }
    }
    if ((!s.last_track_progress_sec || s.last_track_progress_sec === 0) && s.last_track) {
      const startTs = findTrackStartTs(s.last_track, s.last_seen);
      if (startTs) {
        s.last_track_progress_sec = Math.max(0, Math.floor((s.last_seen - startTs) / 1000));
      }
    }
  }

  const summary = db
    .prepare(`
      SELECT
        COUNT(*) as session_count,
        SUM(duration_seconds) as total_seconds,
        MAX(duration_seconds) as longest_session,
        MIN(first_seen) as first_ever_seen,
        MAX(last_seen) as last_ever_seen
      FROM listener_sessions
      WHERE ip = ?
    `)
    .get(ip);
  const alias = getIpAlias(ip);
  const isBot = isBotIp(ip);
  const mostRecent = sessions[0];
  const lastExitTrack = mostRecent?.last_track || '';
  const lastExitTrackProgressSec = mostRecent?.last_track_progress_sec || 0;

  return {
    ip,
    friendlyName: alias?.friendlyName || '',
    notes: alias?.notes || '',
    isBot,
    summary,
    lastExitTrack,
    lastExitTrackProgressSec,
    sessions,
  };
}

function logCustomEvent(type, details, ip = '', mount = '/listen') {
  insertEventStmt.run(Date.now(), type, ip, '', '', '', 0, details, mount);
}

module.exports = {
  db,
  getConfig,
  updateConfig,
  recordPollResult,
  getHistoricalSeries,
  getTimeOfDayProfile,
  getTopReturningListeners,
  getAggregatedStats,
  getIpHistory,
  getIpAliasesMap,
  getIpAlias,
  setIpAlias,
  getBotIpsSet,
  isBotIp,
  setBotIp,
  logCustomEvent,
};
